package interfaces

// 自动刷新点 的 接口

type IBirthPoint interface {
	OnChildRemove(IBall)
}
