package skill

import ()

type ActionAttack2 struct {
	ActionAttack1
}
