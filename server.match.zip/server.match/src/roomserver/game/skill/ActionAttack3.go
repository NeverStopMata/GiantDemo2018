package skill

import ()

type ActionAttack3 struct {
	ActionAttack1
}
