package cll

type IScenePlayer interface {
	AddEatMsg(ballid, beEat uint32)
}
