package ape

type DisplayObject struct {
	x        float32
	y        float32
	rotation float32
}
