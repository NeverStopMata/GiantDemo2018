# behavior3go
golang behavior tree,from http://behavior3.com
