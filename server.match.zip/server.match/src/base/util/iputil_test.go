package util

//import (
//	"testing"
//)

//func TestIputil(t *testing.T) {
//	ips := GetInnerIP()
//	for _, ip := range ips {
//		t.Log("innerip:", ip.String())
//	}
//	ips = GetOuterIP()
//	for _, ip := range ips {
//		t.Log("outerip:", ip.String())
//	}

//	t.Log("ip:", IPStrToUInt("8.8.8.8"))
//}
