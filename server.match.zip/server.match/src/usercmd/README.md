# 说明

本目录下的文件是由proto文件，运行
`proto/gogoproto.bat`
生成的。
