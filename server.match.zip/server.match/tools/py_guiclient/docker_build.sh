#!/bin/bash

docker build -t py_guiclient .
