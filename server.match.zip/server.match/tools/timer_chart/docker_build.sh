#!/bin/bash

docker build -t py_timer_chart .
