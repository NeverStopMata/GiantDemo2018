# todo

* 课程准备
	+ 下载 Go 安装包
	+ 下载 LiteIDE 安装包
	+ 下载 Commandor, 代替 cmd
	+ 下载 Redis 安装包
	+ 下载 Python 安装包
	+ 其他服务器 exe 打包 other_servers.zip